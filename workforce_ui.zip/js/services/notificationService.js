module.exports = notificationService;

function notificationService(httpClientService, $q, $interval, $mdToast){
	var self = this;
	self.subscribe = subscribe;
	self.stopSubscribing = stopSubscribing;
	self.data = {
		collection: []
	};
	self.interval;

	function subscribe(){
		var actionUrl = "getNotification";
		var defer = $q.defer();
		

		function getNotification(){
			httpClientService.clientRequestSSE(actionUrl)
				.then(function(sse){
					sse.onmessage = function(event){
						// if(self.data.collection.length < 10){
							console.log(event);
							var obj = {
								timestamp: event.timeStamp,
								message: event.data
							}
							self.data.collection.push(obj);

							console.log(self.data);
							console.log(self.data.collection);
							displayToast(event.data);
						// }else {
						// 	$interval.cancel(interval);
						// }
						
						sse.close();
						
					}
				});
		}

		self.interval = $interval(getNotification, 5000);
	}

	function displayToast(message){
		$mdToast.show(
			$mdToast.simple()
				.textContent(message)
				.position("bottom left")
				.hideDelay(2000)
		);
	}

	function stopSubscribing(){
		console.log('Invoked stop stopSubscribing');
		$interval.cancel(self.interval);
	}
}