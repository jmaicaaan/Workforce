module.exports = notificationService;

function notificationService(httpClientService, $q, $interval, $mdToast, userService){
	var self = this;
	self.subscribe = subscribe;
	self.stopSubscribing = stopSubscribing;
	self.data = {
		collection: []
	};
	self.interval;
	self.worker;

	function subscribe(){
		var actionUrl = "getNotification";
		var defer = $q.defer();
		
		function getNotification(){
			httpClientService.clientRequestHTMLWorker()
				.then(function(worker){
					self.worker = worker;
					self.worker.postMessage(userService.user.accessToken);
					self.worker.onmessage = function(e){
						console.log(e);

						self.data.collection.push({message: e.data, timestamp: e.timeStamp});

						defer.resolve();
						self.worker.terminate();
						self.worker = undefined;	
					}
				});
		}

		self.interval = $interval(getNotification, 30000);
	}

	function displayToast(message){
		$mdToast.show(
			$mdToast.simple()
				.textContent(message)
				.position("bottom left")
				.hideDelay(2000)
		);
	}

	function stopSubscribing(){
		console.log('Invoked stop stopSubscribing');
		$interval.cancel(self.interval);
	}
}