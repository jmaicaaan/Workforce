module.exports = httpClientService;

function httpClientService($http, serverConfig, localStorageService, $q){
	var self = this;
	self.clientRequest = clientRequest;
	self.clientRequestSSE = clientRequestSSE;
	self.clientRequestHTMLWorker = clientRequestHTMLWorker;

	function clientRequest(actionUrl, actionData, withCredential){

		actionData = injectAccessToken(actionData);
		var dataObject = angular.extend({}, actionData); //Object.getOwnPropertyNames(actionData).length !== 0? actionData : {};

		var config = {
			url: [serverConfig.host, serverConfig.appName, actionUrl].join(serverConfig.delimeter),
			method: "POST",
			headers: {
				"Content-Type": serverConfig.contentType
			},
			data: dataObject,
			withCredentials: withCredential
		};

		return $http(config)
			.then(function(response){
				return response;
			});
	}

	function clientRequestSSE(actionUrl){

		var defer = $q.defer();
		var url = [serverConfig.host, serverConfig.appName, actionUrl].join(serverConfig.delimeter);
		var source = new EventSource(url);

		defer.resolve(source);
		
		return defer.promise;
	}

	function clientRequestHTMLWorker(){

		var defer = $q.defer();
		
		var worker = new Worker("js/services/notificationWorker.js");
		console.log(worker);
		defer.resolve(worker);
		
		return defer.promise;
	}

	function injectAccessToken(dataObject){
		var accessToken = localStorageService.getItemFromLocalStorage("accessToken") != null ? 
							localStorageService.getItemFromLocalStorage("accessToken") : "";
		
		var copy_dataObject = {};
		var userObject = {
			user : {
				accessToken : accessToken	
			}
		};

		angular.extend(copy_dataObject, userObject, dataObject);
		return copy_dataObject;
	}
}