module.exports = httpClientService;

function httpClientService($http, serverConfig, localStorageService){
	var self = this;
	self.clientRequest = clientRequest;

	function clientRequest(actionUrl, actionData, withCredential){

		actionData = injectAccessToken(actionData);
		var dataObject = angular.extend({}, actionData); //Object.getOwnPropertyNames(actionData).length !== 0? actionData : {};

		var config = {
			url: [serverConfig.host, serverConfig.appName, actionUrl].join(serverConfig.delimeter),
			method: "POST",
			headers: {
				"Content-Type": serverConfig.contentType
			},
			data: dataObject,
			withCredentials: withCredential
		};

		return $http(config)
			.then(function(response){
				return response;
			});
	}

	function injectAccessToken(dataObject){
		var accessToken = localStorageService.getItemFromLocalStorage("accessToken") != null ? 
							localStorageService.getItemFromLocalStorage("accessToken") : "";
		
		var copy_dataObject = {};
		var userObject = {
			user : {
				accessToken : accessToken	
			}
		};

		angular.extend(copy_dataObject, userObject, dataObject);
		return copy_dataObject;
	}
}