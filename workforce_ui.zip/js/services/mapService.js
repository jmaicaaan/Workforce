module.exports = mapService;

function mapService(dialogService, workforceService){
	var self = this;
	self.createMap = createMap;
	self.createMapMarker = createMapMarker;

	function createMap(mapElement){
		var mapOptions = {
			zoom: 10,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};
		var map = new google.maps.Map(mapElement, mapOptions);
		return map;
	}

	function createMapMarker(map, markerObject){

		var marker = new google.maps.Marker({
			map: map,
			position: markerObject.position,
			participant: markerObject.participant,
			company: markerObject.company
		});

		marker.addListener("click", markerClickListener);

		function markerClickListener(event){
			
			var selectedDeveloper = this;
			var dialogConfig = {
				event: event,
				templateUrl: "../../views/contactDeveloperDialog.html",
				controller: control,
				locals: {
					developer: selectedDeveloper
				}
			};

			function control(developer){
				var self = this;
				self.developer = developer;
				self.closeSearchDialog = closeSearchDialog;
				self.sendEmail = sendEmail;

				function closeSearchDialog(){
					dialogService.closeDialog();
				}

				function sendEmail(){
					workforceService.sendEmail(self.developer);
				}
			}
			dialogService.showDialog(dialogConfig);
		}

		return marker;
	}
}