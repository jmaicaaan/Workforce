module.exports = companyService;

function companyService(httpClientService, userService){
	var self = this;
	self.company = {};
	self.companyParticipants = [];
	self.getCompanyDetails = getCompanyDetails;
	self.getCompanyParticipants = getCompanyParticipants;
	self.updateCompanyProfile = updateCompanyProfile;
	self.updateCompanyPassword = updateCompanyPassword;

	function setCompanyDetails(companyModel){
		self.company.email = companyModel.email;
		self.company.name = companyModel.name;
		self.company.description = companyModel.description;
		self.company.location = companyModel.location;
		self.company.imageURL = companyModel.imageURL;
		self.company.programmingLanguage = companyModel.programmingLanguageModel.language;
		self.company.website = companyModel.website;

		setUserServiceDetails();
	}

	function setUserServiceDetails(){
		userService.user.displayName = self.company.name
		userService.user.imageURL = self.company.imageURL;
	}

	function getCompanyDetails(){
		var actionUrl = "getCompanyDetails",
			actionData = {},
			withCredential = true;

		return httpClientService.clientRequest(actionUrl, actionData, withCredential)
			.then(function(response){
				setCompanyDetails(response.data.user.companyModel);
				return response;
			});
	}

	function getCompanyParticipants(){
		var actionUrl = "getCompanyParticipants",
			actionData = {},
			withCredential = true;

		return httpClientService.clientRequest(actionUrl, actionData, withCredential)
			.then(function(response){
				var companyParticipants = response.data.user.companyModel.programmingLanguageModel.participantModel;
				self.companyParticipants = companyParticipants; 
				
				console.log(self.companyParticipants);

				return companyParticipants;
			});
	}

	function updateCompanyProfile(company){

		var actionUrl = "updateCompanyProfile",
			actionData = {
				company : company,
				programmingLanguageModel: {
					language : company.programmingLanguage
				}
			},
			withCredential = true;

		return httpClientService.clientRequest(actionUrl, actionData, withCredential)
			.then(function(response){
				console.log("Invoked participantService updateCompanyProfile");
				console.log(response);
			});
	}

	function updateCompanyPassword(company){

		var actionUrl = "updateCompanyPassword",
			actionData = {
				user: company
			},
			withCredential = true;

		return httpClientService.clientRequest(actionUrl, actionData, withCredential)
			.then(function(response){
				console.log("Invoked updateCompanyPassword updateCompanyPassword");
				console.log(response);
				alert("Password changed");
			});

	}
}