module.exports = loginService;

function loginService(httpClientService, userService, localStorageService){
	var self = this;
	self.login = login;

	function login(user){

		localStorageService.deleteItemInLocalStorage("accessToken");

		var actionUrl = "login",
			actionData = {
				user: {
					email: user.email,
					password: user.password
				}
			},
			withCredential = true;

		return httpClientService.clientRequest(actionUrl, actionData, withCredential)
			.then(function(response){
				console.log(response);

				var accessToken = response.data.user.accessToken;
				localStorageService.setItemToLocalStorage("accessToken", accessToken);

				userService.setUserDetails(response.data.user);
				return response.statusText;
			});
	}
}
