var sse;

function timedCount() {
    sse = new EventSource("http://10.128.149.34:8080/workforce/getNotification");
    sse.onmessage = function(e){
    	postMessage(e.data);
    	setTimeout("timedCount()", 500);	
    }
}

timedCount();