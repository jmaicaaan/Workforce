var sse;

self.addEventListener("message", function (e) {
	
	 var accessToken = e.data;
	 
	 var json = {"user": {"accessToken": accessToken}};
	 var jsonUrl = encodeURIComponent(JSON.stringify(json));

	 sse = new EventSource("http://10.128.149.34:8080/workforce/getNotification?accessToken=" + accessToken);
	 sse.onmessage = function(e){
	 	postMessage(e.data);
	 }
});