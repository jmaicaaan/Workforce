module.exports = workforceService;

function workforceService(httpClientService){
	var self = this;
	self.sendEmail = sendEmail;

	function sendEmail(dataObject){

		console.log(dataObject)

		var actionUrl = "sendEmail",
				actionData = {
					participant: dataObject.participant,
					company: dataObject.company
				},
				withCredential = true;

		return httpClientService.clientRequest(actionUrl, actionData, withCredential)
			.then(function(response){
				return response;
			});
	}
}