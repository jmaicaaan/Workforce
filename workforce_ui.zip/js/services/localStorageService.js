module.exports = localStorageService;

function localStorageService($window){
	var self = this;
	self.setItemToLocalStorage = setItemToLocalStorage;
	self.getItemFromLocalStorage = getItemFromLocalStorage;
	self.deleteItemInLocalStorage = deleteItemInLocalStorage;

	function setItemToLocalStorage(key, value){
		$window.localStorage.setItem(key, value);
	}

	function getItemFromLocalStorage(key){
		return $window.localStorage.getItem(key);
	}

	function deleteItemInLocalStorage(key){
		$window.localStorage.removeItem(key);
	}
}