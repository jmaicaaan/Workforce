module.exports = {	
	appName: "workforce",
	host: "http://10.128.149.34:8080", //"http://192.168.1.116:8080", 
	contentType: "application/json",
	delimeter: "/"
};