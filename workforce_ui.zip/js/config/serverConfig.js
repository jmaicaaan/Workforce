module.exports = {	
	appName: "workforce",
	host: "http://localhost:8080",
	contentType: "application/json",
	delimeter: "/"
};