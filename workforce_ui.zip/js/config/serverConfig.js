module.exports = {	
	appName: "workforce",
	host: "http://192.168.1.116:8080",
	contentType: "application/json",
	delimeter: "/"
};