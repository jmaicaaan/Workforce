module.exports = accountComponent;

function accountComponent($timeout){
	return {
		scope: {},
		restrict: "E",
		templateUrl: "../../views/settings/account.html",
		link: linker,
		controller: accountComponentController,
		controllerAs: "vm"
	};

	function linker(scope, elem, attrs){}

	function accountComponentController(userService, participantService, companyService){
		var self = this;
		self.participant = {};
		self.company = {};
		self.userService = userService;
		self.updateParticipantPassword = updateParticipantPassword;
		self.updateCompanyPassword = updateCompanyPassword;


		init();

		function init(){
			userService.getUserAccountType();
		}

		function updateCompanyPassword(){
			companyService.updateCompanyPassword(self.company)
				.then(function(response){
					self.company = {};
					console.log(response);
				});
		}

		function updateParticipantPassword(){
			participantService.updateParticipantPassword(self.participant)
				.then(function(response){
					self.participant = {};
					console.log(response);
				});
		}
	}
}