module.exports = mapComponent;


function mapComponent($mdDialog, dialogService, $q, mapService, geocodingService, companyService){
	return {
		scope: {},
		restrict: "E",
		templateUrl: "../../views/map.html",
		link: linker,
		controller: mapComponentController,
		controllerAs: "vm"
	};
 
	function linker(scope, elem, attrs){
		var map = elem[0].querySelector("#map");
		var bounds = new google.maps.LatLngBounds();
		var googleMap = mapService.createMap(map);
		var promisesOfObject = {
			promises : [],
			participants : []
		};

		companyService.getCompanyParticipants()
			.then(function(companyParticipants){

				console.log(companyParticipants);
				var companyParticipants = companyParticipants;
				
				var markerObject = {};
				markerObject.position = {};
				markerObject.participant = {};

				for(var i = 0; i <= companyParticipants.length - 1; i++){

					var promise = geocodingService.geocodeAddress(companyParticipants[i].location);
					
					promisesOfObject.promises.push(promise);
					promisesOfObject.participants.push(companyParticipants[i]);
				}

				var i = 0;

				$q.all(promisesOfObject.promises).then(function(response){
					console.log(response);

					for(participant in promisesOfObject.participants){

						markerObject.participant = promisesOfObject.participants[participant];
						
						if(i <= response.length){
							markerObject.position = {
								lat: response[i].geometry.location.lat(),
								lng: response[i].geometry.location.lng()
							};
							
							console.log(markerObject);
							var marker = mapService.createMapMarker(googleMap, markerObject);
							bounds.extend(marker.position);
						}
						i++;
					}					
					googleMap.fitBounds(bounds);
				});
			});
	}

	function mapComponentController(){
		var self = this;			
		self.showSearchDialog = showSearchDialog;

		function showSearchDialog(event){

			var dialogConfig = {
				event: event,
				templateUrl: "../../views/searchDeveloperDialog.html",
				controller: control
			};

			function control(){
				var self = this;
				self.closeSearchDialog = closeSearchDialog;

				function closeSearchDialog(){
					dialogService.closeDialog();
				}
			}

			dialogService.showDialog(dialogConfig);
		}
	}
}