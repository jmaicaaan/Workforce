module.exports = dashboardComponent;

function dashboardComponent(){
	return {
		scope: {},
		restrict: "E",
		templateUrl: "../../views/dashboard.html",
		link: linker,
		controller: dashboardComponentController,
		controllerAs: "vm"
	};

	function linker(scope, elem, attrs){

	}

	function dashboardComponentController($mdSidenav, stateService, userService, participantService, companyService, 
					notificationService, dialogService){
		var self = this;
		self.openNav = openNav;
		self.stateTitle = stateService.stateName;
		self.userService = userService;
		self.notificationService = notificationService;
		self.getNotifications = getNotifications;

		init();

		function init(){
			
			userService.getUserAccountType().then(function(response){
				if(response.statusText == "OK"){
					if(userService.isUserAParticipant()){

						participantService.getParticpantDetails();

					}else if(userService.isUserACompany()){
						companyService.getCompanyDetails();
					}	
				}
			});

			notificationService.subscribe();
		}

		function getNotifications(){
			var dialogConfig = {
				event: event,
				templateUrl: "../../views/displayNotificationsDialog.html",
				controller: control,
				locals: {
					notification: notificationService.data
				}
			};

			function control(notification){
				var self = this;
				self.closeDialog = closeDialog;
				self.notification = notification;

				function closeDialog(){
					dialogService.closeDialog();
				}
			}

			dialogService.showDialog(dialogConfig);
		}

		function openNav(){
			$mdSidenav("nav").toggle();
		}
	}
}