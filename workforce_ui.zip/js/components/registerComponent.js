module.exports = registerComponent;

function registerComponent(participantService){
	return {
		scope: {},
		restrict: "E",
		templateUrl: "../../views/register.html",
		link: linker,
		controller: registerComponentController,
		controllerAs: "vm"
	};

	function linker(scope, elem, attrs){

	}

	function registerComponentController(){
		var self = this;
		self.user = {};
		self.register = register;

		function register(){
			participantService.registerParticipant(self.user);
		}
	}
}