module.exports = loginComponent;

function loginComponent(){
	return {
		scope: {},
		restrict: "E",
		templateUrl: "../../views/login.html",
		link: linker,
		controller: loginComponentController,
		controllerAs: "vm"
	};

	function linker(scope, elem, attrs){}

	function loginComponentController($state, githubService, loginService, userService){
		var self = this;
		self.user = {};
		self.login = login;
		self.githubLogin = githubLogin;

		function login(){
			loginService.login(self.user).then(function(statusText){
				if(statusText == "OK"){
					$state.go("dashboard");
				}
			});
		}

		function githubLogin(){
			githubService.githubLogin();
		}
	}
}