package com.workforce.utility;

public interface IAccountTypes {
	
	String ADMIN = "Admin",
			PARTICIPANT = "Participant",
			COMPANY = "Company";
}
