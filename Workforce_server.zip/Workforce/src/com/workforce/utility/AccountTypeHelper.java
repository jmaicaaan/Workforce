package com.workforce.utility;

public class AccountTypeHelper implements IAccountTypes{
	
}
