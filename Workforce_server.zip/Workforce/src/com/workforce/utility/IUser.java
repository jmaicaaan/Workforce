package com.workforce.utility;

public interface IUser {
	
	public String userAccessTokenName = "userToken";
}
