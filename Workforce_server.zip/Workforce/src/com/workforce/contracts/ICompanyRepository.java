package com.workforce.contracts;

import com.workforce.models.UserModel;

public interface ICompanyRepository {
	
	public void RegisterCompany(UserModel user);
	
	public UserModel GetCompanyDetails(UserModel user);
}
