package com.workforce.contracts;

import com.workforce.models.UserModel;

public interface ICompanyRepository {
	
	public UserModel GetCompanyDetailsByAccessToken(String accessToken);
	
}
