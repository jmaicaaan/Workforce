package com.workforce.contracts;

import com.workforce.models.UserModel;

public interface IParticipantRepository {
	
	public void RegisterParticipant(UserModel user);
	
	public UserModel GetParticipantByAccessToken(String accessToken);
	
	public void UpdateParticipatPassword(UserModel user);
}
