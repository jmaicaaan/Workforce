package com.workforce.contracts;

public interface IProgrammingLanguageRepository {
	
	
}
