package com.workforce.contracts;

public interface IProgrammingLanguageRepository {
	
	public int GetIdByLanguage(String language);
}
