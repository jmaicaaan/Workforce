package com.workforce.contracts;

import com.workforce.models.ProgrammingLanguageModel;

public interface IProgrammingLanguageRepository extends IRepository<ProgrammingLanguageModel>{
	
	
}
