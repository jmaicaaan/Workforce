package com.workforce.contracts;

import java.util.Collection;

public interface IRepository<T> {
	
	public void Insert(T entity);
	
	public void Update(T entity);
	
	public Collection<T> GetList();
}
