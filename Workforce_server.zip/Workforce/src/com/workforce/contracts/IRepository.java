package com.workforce.contracts;

import java.util.List;

public interface IRepository<T> {
	
	public void Insert(T entity);
	
	public void Update(T entity);
	
	public List<T> GetList(T entity);
	
}
