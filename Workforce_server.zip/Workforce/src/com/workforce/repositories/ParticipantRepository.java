package com.workforce.repositories;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.workforce.contracts.IParticipantRepository;
import com.workforce.models.ParticipantModel;
import com.workforce.models.UserModel;
import com.workforce.utility.HibernateFactory;

public class ParticipantRepository extends CrudRepository<ParticipantModel> implements IParticipantRepository {
	
	@Override
	public void RegisterParticipant(UserModel user) {
		// TODO Auto-generated method stub
		
		Session session = null;
		Transaction trans = null;
		
		try {
			
			session = HibernateFactory.getSession().openSession();
			trans = session.beginTransaction();
			session.save(user);
			trans.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			if(trans != null)
				trans.rollback();
			e.printStackTrace();
		}
	}
	
	@Override
	public UserModel GetParticipantByAccessToken(String accessToken) {
		// TODO Auto-generated method stub
		
		Session session = null;
		Transaction trans = null;
		UserModel userModel = new UserModel();
		
		try {
			session = HibernateFactory.getSession().openSession();
			trans = session.beginTransaction();
			
			userModel = (UserModel) session.createQuery("from Users where accessToken = :accessToken")
				.setParameter("accessToken", accessToken)
				.uniqueResult();
			
			trans.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(trans != null)
				trans.rollback();
		}
		
		return userModel;
	}
}
