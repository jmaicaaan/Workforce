package com.workforce.repositories;

import com.workforce.contracts.IProgrammingLanguageRepository;
import com.workforce.models.ProgrammingLanguageModel;


public class ProgrammingLanguageRepository extends CrudRepository<ProgrammingLanguageModel> implements IProgrammingLanguageRepository {
	
}
