package com.workforce.repositories;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.workforce.contracts.IProgrammingLanguageRepository;
import com.workforce.models.ProgrammingLanguageModel;
import com.workforce.utility.HibernateFactory;

public class ProgrammingLanguageRepository implements IProgrammingLanguageRepository {

	@Override
	public void Insert(ProgrammingLanguageModel entity) {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction trans = null;
		
		try {
			session = HibernateFactory.getSession().openSession();
			trans = session.beginTransaction();
			session.save(entity);
			trans.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(trans != null)
				trans.rollback();
			e.printStackTrace();
		}
		
		session.close();
	}

	@Override
	public void Update(ProgrammingLanguageModel entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Collection<ProgrammingLanguageModel> GetList() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction trans = null;
		List<ProgrammingLanguageModel> programmingLanguageList = new ArrayList<ProgrammingLanguageModel>();
		
		try {
			session = HibernateFactory.getSession().openSession();
			trans = session.beginTransaction();
			
			Criteria cr = session.createCriteria(ProgrammingLanguageModel.class);
			programmingLanguageList = (List<ProgrammingLanguageModel>) cr.list();
			
			trans.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(trans != null)
				trans.rollback();
			e.printStackTrace();
		}
		
		return programmingLanguageList;
	}
}
