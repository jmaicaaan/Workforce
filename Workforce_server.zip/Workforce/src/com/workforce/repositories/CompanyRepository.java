package com.workforce.repositories;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.workforce.contracts.ICompanyRepository;
import com.workforce.models.CompanyModel;
import com.workforce.models.UserModel;
import com.workforce.utility.HibernateFactory;

public class CompanyRepository extends CrudRepository<CompanyModel> implements ICompanyRepository{

	@Override
	public UserModel GetCompanyDetailsByAccessToken(String accessToken) {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction trans = null;
		UserModel userModel = new UserModel();
		
		try {
			session = BaseRepository.getSession().openSession();
			trans = session.beginTransaction();
			userModel = (UserModel) session.createQuery("from Users where accessToken = :accessToken")
						.setParameter("accessToken", accessToken)
						.uniqueResult();
			trans.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			if(trans != null)
				trans.rollback();
			e.printStackTrace();
		}
		
		return userModel;
	}
	
	
}
